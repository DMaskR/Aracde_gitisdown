/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Load
*/
#include <exception>
#include <dlfcn.h>
#include <iostream>
#include <memory>
#include <string>
#include "changeLib.hpp"

changeLib::changeLib()
{

}

changeLib::~changeLib()
{

}

void *changeLib::switchLib(const std::string &path)
{
    void *lib = dlopen(path.c_str(), RTLD_NOW | RTLD_LAZY);

    if (!lib) {
        std::cerr << dlerror() << std::endl;
        throw std::exception();
    }
    return lib;
}

void changeLib::closeLib(void *lib)
{
    if (dlclose(lib) != 0)
        std::cerr << dlerror() << std::endl;
}
