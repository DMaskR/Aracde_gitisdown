/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** AGraph abstract class
*/

#ifndef AGraph_HPP_
#define AGraph_HPP_

#include <vector>
#include <string>
#include <map>
#include "Misc.hpp"


#define MAP_COORD(x, y) (x * y / 100)

namespace Arcade {
    class AGraph {
        public:
            virtual ~AGraph() = default;
            // virtual void playSound() = 0;
            // virtual void stopSound() = 0;
            virtual void closeWindow() = 0;
            virtual void displayBox(std::vector<int> pos, std::vector<int> size, int type = 0) = 0;
            virtual void displayCharacter(std::vector<std::vector<int>> charater, std::vector<int> pos) = 0;
            virtual void displayObject(std::string name, std::vector<int> pos) = 0;
            virtual void displayText(std::vector<int> pos, int size, std::string acStr, const std::string &couleur = "white") = 0;
            virtual void drawMap(std::map<int, std::vector<int>> map, std::vector<int> pos) = 0;
            virtual void openWindow() = 0;
            virtual void setAssets(const std::string &name) = 0;
            virtual void updateWindow() = 0;
            virtual Arcade::Event lookEvent() = 0;
            virtual std::string getName() const = 0;
            virtual std::string getPlayerName(std::vector<int> pos) = 0;
            virtual std::vector<int> getPos(const std::string &id) = 0;
    };
}
#endif /* !AGraph_HPP_ */
