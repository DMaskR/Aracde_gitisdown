/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Misc
*/

#ifndef MISC_HPP_
#define MISC_HPP_

namespace Arcade
{
    enum Event {
        ECHAP,
        KEYDOWN,
        KEYUP,
        KEYLEFT,
        KEYRIGHT,
        NEXTGAME,
        PREVGAME,
        NEXTLIB,
        PREVLIB,
        ENTER,
        SPACE,
        BW,
        BX,
        NOTHING
    };
}

#endif /* !MISC_HPP_ */
