/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Hud
*/

#ifndef HUD_HPP_
#define HUD_HPP_
#include <vector>
#include <string>
#include "AGraph.hpp"

class Hud {
    public:
        Hud();
        ~Hud();
                std::string getName() const {return _name;};
                void loadGameName(std::vector<std::string> gameName) {_listGame = gameName;};
                void setFalseName() {_goodName = false;};
                size_t getScore(int selected, int id) const {return _score[selected][id];};
                void playerName(std::shared_ptr<Arcade::AGraph> lib);
                void setName(char c) {_name += c;};
                bool getValid() const {return _goodName;};
                std::string getGame(int id) const {return _listGame[id];};
                void drawHUD(std::shared_ptr<Arcade::AGraph> lib, const std::string &name, int score);
                void switchLibName(std::vector<std::string> libName) {_listLib = libName;};
    private:
                std::string _name;
                std::vector<std::vector<size_t>> _score;
                std::vector<std::string> _listGame;
                std::vector<std::string> _listLib;
                bool _goodName;
};

#endif /* !HUD_HPP_ */
