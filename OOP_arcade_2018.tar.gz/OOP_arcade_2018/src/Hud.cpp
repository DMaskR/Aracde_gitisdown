/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Hud
*/
#include <memory>
#include "Hud.hpp"

Hud::Hud() : _name(), _score(), _listGame(), _goodName(false)
{

}

Hud::~Hud()
{

}

void Hud::drawHUD(std::shared_ptr<Arcade::AGraph> lib, const std::string &name, int score)
{
    lib->displayObject(name, lib->getPos("Title"));
    lib->displayText(lib->getPos("posTitleScore"), 40, "Score");
    lib->displayText({75, 10}, 20, "How to play :");
    lib->displayText({82, 10}, 20, "Arrow up: to go up");
    lib->displayText({85, 10}, 20, "Arrow left: to go left");
    lib->displayText({88, 10}, 20, "Arrow right: to go right");
    lib->displayText({91, 10}, 20, "Arrow down: to go down");
    lib->displayText({82, 35}, 20, "Q: to change library");
    lib->displayText({85, 35}, 20, "A: to change game");
    lib->displayText({88, 35}, 20, "ESC: to quit the program");
    lib->displayText(lib->getPos("posScore"), 20, std::to_string(score), "white");
}

void Hud::playerName(std::shared_ptr<Arcade::AGraph> lib)
{
    _goodName = false;
    lib->displayText(lib->getPos("posQuestion"), 40, "WHAT'S YOUR NAME");
    lib->displayBox(lib->getPos("posBoxname"), lib->getPos("sizeBoxname"));
    _name = lib->getPlayerName(lib->getPos("posName"));
    if (_name != "")
        _goodName = true;
}
