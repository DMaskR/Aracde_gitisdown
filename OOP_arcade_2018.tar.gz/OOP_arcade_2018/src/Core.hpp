/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Core
*/

#ifndef CORE_HPP_
#define CORE_HPP_

#include "changeLib.hpp"
#include "AGame.hpp"
#include "AGraph.hpp"
#include "Hud.hpp"

namespace Arcade {
    class Core {
        public:
            Core(const std::string &lib);
            ~Core();
            void mLoop();
            void gLoop();
            void switchGame(int i);
            void switchGraphical(int i);
            void loadGraphical();
            void loadGame();
            void lookEvent();
            std::vector<std::string> getGameName() const;
            std::vector<std::string> getLibName() const;
        private:
            changeLib _changeLib;
            Hud _hud;
            std::vector<void *> _graph;
            size_t _sGame;
            size_t _sGraph;
            std::vector<std::shared_ptr<AGame>> _listGame;
            std::vector<std::shared_ptr<AGraph>> _listGraph;
            Arcade::Event _event;
            std::string _name;
    };
}
#endif /* !CORE_HPP_ */
