/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Core.cpp
*/

#include "Core.hpp"
#include <iostream>
#include <algorithm>
#include <dirent.h>
#include <string>

Arcade::Core::Core(const std::string &lib) :
_changeLib(), _hud(), _graph(), _sGame(0), _sGraph(0), _listGame(),_listGraph()
{
    _graph.push_back(_changeLib.switchLib(lib));
    _listGraph.push_back(_changeLib.getPtr<AGraph>(_graph[0], "Lib"));
    _name = _listGraph[0]->getName();
    loadGraphical();
    loadGame();
    _listGraph[_sGraph]->openWindow();
    _hud.loadGameName(getGameName());
    _hud.switchLibName(getLibName());
}

Arcade::Core::~Core()
{

}

void Arcade::Core::mLoop()
{
    while (1) {
            _sGame = 0;
            _listGraph[_sGraph]->setAssets(_listGame[_sGame]->getName());
            gLoop();
    }
    _listGraph[_sGraph]->closeWindow();
}

void Arcade::Core::gLoop()
{
    _listGraph[_sGraph]->setAssets(_listGame[_sGame]->getName());
    while (1) {
        _listGraph[_sGraph]->updateWindow();
        _event = _listGraph[_sGraph]->lookEvent();
        lookEvent();
        if (_listGame[_sGame]->lose() == true) {
             if (!_hud.getValid())
                _hud.playerName(_listGraph[_sGraph]);
            _listGraph[_sGraph]->displayText({23, 40}, 35, "Player: ");
            _listGraph[_sGraph]->displayText({23, 47}, 35, _hud.getName());
            _listGraph[_sGraph]->displayText({50, 35}, 80, "GAME OVER");
            _listGraph[_sGraph]->displayText({73, 33}, 40, "Press enter to restart the game");
            if (_event == ENTER)
                _listGame[_sGame]->resetGame();
            continue;
        }
        _hud.setFalseName();
        _listGame[_sGame]->updateGame(_event);
        _listGraph[_sGraph]->drawMap(_listGame[_sGame]->getMap(), _listGraph[_sGraph]->getPos("Map"));
        _listGraph[_sGraph]->displayCharacter(_listGame[_sGame]->getCharacter(), _listGraph[_sGraph]->getPos("Map"));
        _hud.drawHUD(_listGraph[_sGraph], _listGame[_sGame]->getName(), _listGame[_sGame]->getScore());
	}
}

void Arcade::Core::switchGame(int i)
{
    _sGame = i;

    if (_sGame == (size_t)(-1))
        _sGame = _listGame.size() - 1;
    if (_sGame >= _listGame.size())
        _sGame = 0;
    _listGraph[_sGraph]->setAssets(_listGame[_sGame]->getName());
}

void Arcade::Core::switchGraphical(int i)
{
    _listGraph[_sGraph]->closeWindow();
    _sGraph = i;

    if (_sGraph == (size_t)(0 - 1))
        _sGraph = _listGraph.size() - 1;
    if (_sGraph >= _listGraph.size())
        _sGraph = 0;
    _listGraph[_sGraph]->setAssets(_listGame[_sGame]->getName());
    _listGraph[_sGraph]->openWindow();
}

void Arcade::Core::loadGame()
{
    std::vector<std::string> game;
    DIR *dir;
    int i = _listGraph.size();
    struct dirent *ent;

    if ((dir = opendir("./games")) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            std::string result = ent->d_name;
            if (result.find(".so") != std::string::npos)
                game.push_back(result);
        }
        closedir(dir);
    } else
        throw std::exception();
    for (auto x : game) {
        _graph.push_back(_changeLib.switchLib("./games/" + x));
        _listGame.push_back(_changeLib.getPtr<AGame>(_graph[i], "Game"));
        i++;
    }
}

void Arcade::Core::loadGraphical()
{
    std::vector<std::string> lib;
    DIR *acDir;
    struct dirent *d;
    int s = 1;

    if ((acDir = opendir("./lib")) != NULL) {
        while ((d = readdir(acDir)) != NULL) {
            std::string result = d->d_name;
            if (result.find(".so") != std::string::npos  && result.find(_name) == std::string::npos)
                lib.push_back(result);
        }
        closedir(acDir);
    } else
        throw std::exception();
    for (auto x : lib) {
        _graph.push_back(_changeLib.switchLib("./lib/" + x));
        _listGraph.push_back(_changeLib.getPtr<AGraph>(_graph[s], "Lib"));
        s++;
    }
}

void Arcade::Core::lookEvent()
{
    if (_event == ECHAP)
        exit(0);
    if (_event == NEXTGAME)
        switchGame(_sGame + 1);
    if (_event == PREVGAME)
        switchGame(_sGame - 1);
    if (_event == NEXTLIB)
        switchGraphical(_sGraph + 1);
    if (_event == PREVLIB)
        switchGraphical(_sGraph -1);
}

std::vector<std::string> Arcade::Core::getGameName() const
{
    std::vector<std::string> name;

    for (auto x : _listGame)
        name.push_back(x->getName());
    return (name);
}

std::vector<std::string> Arcade::Core::getLibName() const
{
    std::vector<std::string> name;

    for (auto x : _listGraph)
        name.push_back(x->getName());
    return (name);
}
