/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Main.cpp
*/

#include "Core.hpp"

int main(int ac, char **av)
{
    if (ac != 2)
        exit(84);
    try {
        Arcade::Core core(av[1]);
        core.mLoop();
    } catch(std::exception &exception) {
        exception.what();
        return(84);
    }
    return (0);
}
