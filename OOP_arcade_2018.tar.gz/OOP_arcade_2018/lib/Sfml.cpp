/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Sfml.cpp
*/

#include <SFML/Graphics.hpp>
#include <fstream>
#include <unistd.h>
#include "Sfml.hpp"

extern "C"
{
    Sfml *allocatorLib()
    {
        return new Sfml();
    }

    void deleterLib(Sfml *pointer)
    {
        delete pointer;
    }
}

Sfml::Sfml() :  _win(), _vec(), _sprite(), _event(),
_texture(), _enemies(), _wall(), _objet(), _character(), _hud(), _Objmap(), _clock()
{
    sf::RectangleShape box = sf::RectangleShape();
    box.setOutlineThickness(1);
    box.setOutlineColor(sf::Color::White);
    box.setFillColor(sf::Color::Transparent);
    _vec.push_back(box);
    if (!_font.loadFromFile("./lib/sfml/Arimo.ttf"))
        throw std::exception();
    _hud.emplace("Map", std::vector<int>({20, 3}));
    _hud.emplace("Title", std::vector<int>({0,17}));
    _hud.emplace("posName", std::vector<int>({63, 33}));
    _hud.emplace("posBoxname", std::vector<int>({60, 29}));
    _hud.emplace("sizeBoxname", std::vector<int>({10,40}));
    _hud.emplace("posQuestion", std::vector<int>({35, 40}));
    _hud.emplace("posTitleScore", std::vector<int>({5, 85}));
    _hud.emplace("posScore", std::vector<int>({12, 87}));
    
}

Sfml::~Sfml()
{

}

void Sfml::openWindow()
{
    _win.create(sf::VideoMode(1920,1200), "ARCADE SFML");
}

void Sfml::closeWindow()
{
    _win.close();
}

void Sfml::displayBox(std::vector<int> pos, std::vector<int> size, int type)
{
    sf::RectangleShape box = sf::RectangleShape(_vec[type]);
    box.setPosition((float)MAP_TRANS_X(pos[1], (int)_win.getSize().x), (float)MAP_TRANS_Y(pos[0], (int)_win.getSize().y));
    box.setSize({(float)MAP_TRANS_X(size[1], (int)_win.getSize().x), (float)MAP_TRANS_Y(size[0], (int)_win.getSize().y)});
    _win.draw(box);
}

void Sfml::displayObject(std::string name, std::vector<int> pos)
{
    (void)pos;
    (void)name;
    sf::Sprite sprite;
    sf::Texture texture;
    if(texture.loadFromFile("./lib/sfml/" + name + ".png")) {
        sprite.setTexture(texture);
        sprite.setPosition((float)MAP_COORD(pos[1], (int)_win.getSize().x), (float)MAP_COORD(pos[0], (int)_win.getSize().y));
        _win.draw(sprite);
    } else
        throw std::exception();
}

void Sfml::displayText(std::vector<int> pos, int size, std::string str,  const std::string &couleur)
{
    static sf::Text *text = new sf::Text();
    sf::Color color(255, 255, 255);

    text->setFont(_font);
    text->setString(str);
    text->setCharacterSize(size);
    if (couleur == "white")
        text->setFillColor(sf::Color::White);
    text->setPosition((float)MAP_COORD(pos[1], (int)_win.getSize().x), (float)MAP_COORD(pos[0], (int)_win.getSize().y));
    _win.draw(*text);
}

Arcade::Event Sfml::lookEvent()
{
    sf::Event event;

    if (_win.pollEvent(event)) {
        if (event.type == sf::Event::KeyPressed) {
            if (event.key.code == sf::Keyboard::Escape)
                return Arcade::Event::ECHAP;
            if (event.key.code == sf::Keyboard::Up)
                return Arcade::Event::KEYUP;
            if (event.key.code == sf::Keyboard::Right)
                return Arcade::Event::KEYRIGHT;
            if (event.key.code == sf::Keyboard::Left)
                return Arcade::Event::KEYLEFT;
            if (event.key.code == sf::Keyboard::Down)
                return Arcade::Event::KEYDOWN;
            if (event.key.code == sf::Keyboard::Enter)
                return Arcade::Event::ENTER;
            if (event.key.code == sf::Keyboard::Space)
                return Arcade::Event::SPACE;
            if (event.key.code == sf::Keyboard::A)
                return Arcade::Event::PREVGAME;
            if (event.key.code == sf::Keyboard::Z)
                return Arcade::Event::NEXTGAME;
            if (event.key.code == sf::Keyboard::Q)
                return Arcade::Event::PREVLIB;
            if (event.key.code == sf::Keyboard::S)
                return Arcade::Event::NEXTLIB;
            if (event.key.code == sf::Keyboard::W)
                return Arcade::Event::BW;
            if (event.key.code == sf::Keyboard::X)
                return Arcade::Event::BX;
        }
        return Arcade::Event::NOTHING;
    }
    return Arcade::Event::NOTHING;
}

std::string Sfml::getPlayerName(std::vector<int> pos)
{
    (void)pos;
    std::string str = "";
    sf::Event event;

    while (1) {
        _win.display();
        _win.waitEvent(event);
        if (event.type == sf::Event::TextEntered) {
            if (event.text.unicode < 128) {
                str += static_cast<char>(event.text.unicode);
                displayText(pos, 20, str);
            }
        }
        if (event.type == sf::Event::KeyPressed) {
            if (event.key.code == sf::Keyboard::Enter && str != "")
                break;
        }
    }
    return str;
}

void Sfml::displayCharacter(std::vector<std::vector<int>> character, std::vector<int> pos)
{
    float x0 = MAP_COORD(pos[1], (int)_win.getSize().x);
    float y0 = MAP_COORD(pos[0], (int)_win.getSize().y);

    for(auto x : character) {
        sf::Sprite sprite(_character.front());
        sprite.setPosition({x[1] * 19 + x0, x[0] * 19 + y0});
        _win.draw(sprite);
    }
}

void Sfml::updateWindow()
{
    sf::Time time = _clock.getElapsedTime();
    _win.display();
    float elapsed = time.asMicroseconds();
    while (elapsed < 90000)
        elapsed = _clock.getElapsedTime().asMicroseconds();
    _clock.restart();
    _win.clear();
}

void Sfml::setAssets(const std::string &name)
{
    _character.clear();
    _enemies.clear();
    _objet.clear();
    _wall.clear();
    _Objmap.clear();
    _texture.clear();
    sf::Texture texture;
    sf::Sprite sprite;
    int i = 0;
    if (_character.size() > 0)
        _Objmap.emplace("character", _character);
    while (std::ifstream("./lib/sfml/" + name + "/object" + std::to_string(i) + ".png")) {
        texture.loadFromFile("./lib/sfml/" + name + "/object" + std::to_string(i) + ".png");
        _texture.push_back(sf::Texture(texture));
        sprite.setTexture(_texture.back());
        sprite.setScale(0.5f, 0.5f);
        _objet.push_back(sf::Sprite(sprite));
        i++;
    }
    i = 0;
    if (_objet.size() > 0)
        _Objmap.emplace("objet", _objet);
    while (std::ifstream("./lib/sfml/" + name + "/wall" + std::to_string(i) + ".png")) {
        texture.loadFromFile("./lib/sfml/" + name + "/wall" + std::to_string(i) + ".png");
        _texture.push_back(sf::Texture(texture));
        sprite.setTexture(_texture.back());
        sprite.setScale(0.4f, 0.4f);
        _wall.push_back(sf::Sprite(sprite));
        i++;
    }
    i = 0;
    while (std::ifstream("./lib/sfml/" + name + "/player" + std::to_string(i) + ".png")) {
        texture.loadFromFile("./lib/sfml/" + name + "/player" + std::to_string(i) + ".png");
        _texture.push_back(sf::Texture(texture));
        sprite.setTexture(_texture.back());
        sprite.setScale(0.5f, 0.5f);
        _character.push_back(sf::Sprite(sprite));
        i++;
    }
    i = 0;
    if (_wall.size() > 0)
        _Objmap.emplace("wall", _wall);
    while (std::ifstream("./lib/sfml/" + name + "/enemy" + std::to_string(i) + ".png")) {
        texture.loadFromFile("./lib/sfml/" + name + "/enemy" + std::to_string(i) + ".png");
        _texture.push_back(sf::Texture(texture));
        sprite.setTexture(_texture.back());
        sprite.setScale(0.5f, 0.5f);
        _enemies.push_back(sf::Sprite(sprite));
        i++;
    }
    if (_enemies.size() > 0)
    _Objmap.emplace("enemy", _enemies);
}

void Sfml::displayObjOnMap(const std::string &type, int i, std::vector<int> pos)
{
    if (_Objmap.find(type) != _Objmap.end()) {
        sf::Sprite sprite(_Objmap[type][i]);
        sprite.setPosition({(float)pos[1], (float)pos[0]});
        _win.draw(sprite);
    }
}

// void Sfml::playSound()
// {
//     sf::SoundBuffer buffer;
//     buffer.loadFromFile("/rsc/arcade.ogg");
//
//     _sound.setBuffer(buffer);
//     _sound.play();
// }
//
// void Sfml::stopSound()
// {
//     _sound.stop();
// }

void Sfml::drawMap(std::map<int, std::vector<int>> map, std::vector<int> pos)
{
    float x0 = MAP_COORD(pos[1], (int)_win.getSize().x);
    float y0 = MAP_COORD(pos[0], (int)_win.getSize().y);
    int x = 0;
    int y = 0;

    for (auto m : map) {
        x = 0;
        for (auto i : m.second) {
            if (i == 1)
                displayObjOnMap("wall", 0, {y * 19 + (int)y0,x * 19 + (int)x0});
            if (i >= 10)
                displayObjOnMap("objet", i - 10, {y * 19 + (int)y0, x * 19 + (int)x0});
            if (i < 0)
                displayObjOnMap("enemy" ,-i - 1, {y * 19 + (int)y0, x * 19 + (int)x0});
            x++;
        }
        y++;
    }
}
