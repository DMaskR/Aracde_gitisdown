/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Ncurse
*/

#include <ncurses.h>
#include <string>
#include <fstream>
#include <unistd.h>
#include "Ncurse.hpp"

extern "C" {
    Ncurse *allocatorLib() {
        return new Ncurse();
    }
    void deleterLib(Ncurse *pointer) {
        delete pointer;
    }
}

Ncurse::Ncurse() : _key(0), _enemy(), _wall(), _objet(), _character(), _Objmap(), _posMenu()
{
    _posMenu.emplace("posName", std::vector<int>({65, 33}));
    _posMenu.emplace("sizeBoxname", std::vector<int>({10,40}));
    _posMenu.emplace("Map", std::vector<int>({30, 5}));
    _posMenu.emplace("posTitleScore", std::vector<int>({70, 70}));
    _posMenu.emplace("posQuestion", std::vector<int>({55, 45}));
    _posMenu.emplace("Title", std::vector<int>({0,20}));
    _posMenu.emplace("posScore", std::vector<int>({75, 70}));
    _posMenu.emplace("posBoxname", std::vector<int>({60, 29}));
}

void Ncurse::openWindow()
{
    initscr();
    cbreak();
    keypad(stdscr, TRUE);
    nodelay(stdscr, TRUE);
    noecho();
    refresh();
}

void Ncurse::closeWindow()
{
    endwin();
}

Ncurse::~Ncurse()
{
    endwin();
}

void Ncurse::displayObject(std::string name, std::vector<int> pos)
{
    int col;
    int row;
    getmaxyx(stdscr,row,col);
    int x = MAP_COORD(pos[1], col);
    int y = MAP_COORD(pos[0], row);
    std::ifstream file("./lib/ncurse/" + name + ".txt");
    std::string string;
    if (file)
        while (getline(file, string)) {
            mvprintw(y, x, string.c_str());
            y++;
        } else
            throw std::exception();
}

void Ncurse::displayText(std::vector<int> pos, int size, std::string str, const std::string &color)
{
    int col;
    int row;
    getmaxyx(stdscr,row,col);
    int x = MAP_COORD(pos[1], col);
    int y = MAP_COORD(pos[0], row);
    (void)color;
	mvprintw(y, x, str.c_str());
}

Arcade::Event Ncurse::lookEvent()
{
    (_key = getch());
	if (_key == KEY_LEFT)
	return Arcade::Event::KEYLEFT;
	if (_key == KEY_RIGHT)
	return Arcade::Event::KEYRIGHT;
	if (_key == KEY_UP)
	return Arcade::Event::KEYUP;
	if (_key == KEY_DOWN)
	return Arcade::Event::KEYDOWN;
    if (_key == 119)
        return Arcade::Event::BW;
    if (_key == 120)
        return Arcade::Event::BX;
    if (_key == 10)
        return Arcade::Event::ENTER;
    if (_key == 27)
        return Arcade::Event::ECHAP;
    if (_key == KEY_BACKSPACE)
        return Arcade::Event::SPACE;
     if (_key == 122)
        return Arcade::Event::NEXTGAME;
    if (_key == 97)
        return Arcade::Event::PREVGAME;
    if (_key == 113)
        return Arcade::Event::PREVLIB;
    if (_key == 115)
        return Arcade::Event::NEXTLIB;
    return Arcade::Event::NOTHING;
}

void Ncurse::displayBox(std::vector<int> pos, std::vector<int> size, int type)
{
    int col;
    int row;
    getmaxyx(stdscr,row,col);
    int x = MAP_COORD(pos[1], col);
    int y = MAP_COORD(pos[0], row);
    int sizex = MAP_COORD(size[1], col);
    int sizey = MAP_COORD(size[0], row);
    (void)type;
    std::string p;
    std::string voids;
    std::string wall = "#";

    p += wall;
    voids += wall;
    for (int i = 1; i < sizex - 1; i++) {
        p += wall;
        voids += " ";
    }
    p += wall;
    voids += wall;
    mvprintw(y, x, p.c_str());
    for (int i = 1; i < sizey - 1; i++)
        mvprintw(y + i, x, voids.c_str());
    mvprintw(y + sizey - 1, x, p.c_str());
}

std::string Ncurse::getPlayerName(std::vector<int> pos)
{
    int col, row;
    getmaxyx(stdscr,row,col);
    int x = MAP_COORD(pos[1], col);
    int y = MAP_COORD(pos[0], row);
    char tmp[21];

    echo();
    nodelay(stdscr, FALSE);
    mvgetnstr(y, x, tmp, 20);
    noecho();
    nodelay(stdscr, TRUE);
    return (std::string(tmp));
}

void Ncurse::updateWindow(void)
{
    refresh();
    usleep(100000);
    clear();
}

void Ncurse::displayCharacter(std::vector<std::vector<int>> character, std::vector<int> pos)
{
    int col;
    int row;
    getmaxyx(stdscr,row,col);
    int x = MAP_COORD(pos[1], col);
    int y = MAP_COORD(pos[0], row);

    for(int i = 0; i < character.size(); i++) {
        if (i == 0)
            mvprintw(character.at(i)[0] + y, character.at(i)[1] + x, _character[0].c_str());
        else
            mvprintw(character.at(i)[0] + y, character.at(i)[1] + x, _character[1].c_str());
    }
}

void Ncurse::setAssets(const std::string &name)
{
    std::ifstream character("./lib/ncurse/" + name + "/player.txt");
    std::ifstream objet("./lib/ncurse/" + name + "/object.txt");
    std::ifstream wall("./lib/ncurse/" + name + "/wall.txt");
    std::ifstream enemy("./lib/ncurse/" + name + "/enemy.txt");
    std::string result;
    _character.clear();
    _enemy.clear();
    _objet.clear();
    _wall.clear();
    _Objmap.clear();
    if (character) {
        while(getline(character, result))
            _character.push_back(result);
        _Objmap.emplace("character", _character);
    }
    if (objet) {
        while(getline(objet, result))
            _objet.push_back(result);
        _Objmap.emplace("objet", _objet);
    }
    if (wall) {
        while(getline(wall, result))
            _wall.push_back(result);
        _Objmap.emplace("wall", _wall);
    }
    if (enemy) {
        while(getline(enemy, result))
            _enemy.push_back(result);
        _Objmap.emplace("enemy", _enemy);
    }
}

void Ncurse::drawObjMap(const std::string &type, int id, std::vector<int> pos)
{
    if (_Objmap.find(type) != _Objmap.end())
        mvprintw(pos[0], pos[1], _Objmap[type][id].c_str());
}

void Ncurse::drawMap(std::map<int, std::vector<int>> map, std::vector<int> pos)
{
    int row;
    int col;
    getmaxyx(stdscr,row,col);
    int x0 = MAP_COORD(pos[1], col);
    int y0 = MAP_COORD(pos[0], row);
    int x = 0;
    int y = 0;

    for (auto m : map) {
        x = 0;
        for (auto i : m.second) {
            if (i == 1)
                drawObjMap("wall", 0, {y + y0, x + x0});
            if (i >= 10)
                drawObjMap("objet", i - 10, {y + y0, x + x0});
            if (i < 0)
                drawObjMap("enemy" ,-i - 1, {y + y0, x + x0});
            x++;
        }
        y++;
    }
}
