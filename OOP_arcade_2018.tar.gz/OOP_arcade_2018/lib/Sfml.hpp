/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Sfml
*/

#ifndef SFML_HPP_
#define SFML_HPP_

#define MAP_TRANS_X(x, y) (MAP_COORD(x, y / 8) * 8)
#define MAP_TRANS_Y(x, y) (MAP_COORD(x, y / 16) * 16)
#include "AGraph.hpp"

class Sfml : public Arcade::AGraph {
    public:
        Sfml();
        ~Sfml();
        void openWindow();
        void closeWindow();
        void updateWindow();
        void displayBox(std::vector<int> pos, std::vector<int> size, int type = 0);
        void displayObject(std::string name, std::vector<int> pos);
        void displayText(std::vector<int> pos, int size, std::string str,  const std::string &couleur = "white");
        Arcade::Event lookEvent();
        std::string getPlayerName(std::vector<int> pos);
        void setAssets(const std::string &name);
        void displayCharacter(std::vector<std::vector<int>> charater, std::vector<int> pos);
        void drawMap(std::map<int, std::vector<int>> map, std::vector<int> pos);
        std::string getName() const {return "sfml";};
        std::vector<int> getPos(const std::string &id) {return _hud[id];};
    private:
        sf::RenderWindow _win;
        std::vector<sf::RectangleShape> _vec;
        sf::Sprite _sprite;
        sf::Font _font;
        sf::Event _event;
        std::vector<sf::Texture> _texture;
        std::vector<sf::Sprite> _enemies;
        std::vector<sf::Sprite> _wall;
        std::vector<sf::Sprite> _objet;
        std::vector<sf::Sprite> _character;
        std::map<std::string, std::vector<int>> _hud;
        std::map<std::string, std::vector<sf::Sprite>> _Objmap;
        sf::Clock _clock;
        void displayObjOnMap(const std::string &type, int id, std::vector<int> pos);

};

#endif /* !SFML_HPP_ */
