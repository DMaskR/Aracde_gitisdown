/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Ncurse.hpp
*/

#ifndef NCURSE_HPP_
#define NCURSE_HPP_

#include "AGraph.hpp"

typedef struct _win_border_struct {
    chtype ls, rs, ts, bs,
    tl, tr, bl, br;
}WIN_BORDER;

typedef struct _WIN_struct {
    int startx, starty;
    int height, width;
    WIN_BORDER border;
}WIN;

class Ncurse : public Arcade::AGraph {
    public:
        Ncurse();
        ~Ncurse();
        void openWindow();
        void closeWindow();
        void updateWindow(void);
        void displayBox(std::vector<int> pos, std::vector<int> size, int type = 0);
        void displayObject(std::string name, std::vector<int> pos);
        void displayText(std::vector<int> pos, int size, std::string str, const std::string &color = "white");
        Arcade::Event lookEvent();
        std::string getPlayerName(std::vector<int> pos);
        void setAssets(const std::string &name);
        void drawMap(std::map<int, std::vector<int>> map, std::vector<int> pos);
        void displayCharacter(std::vector<std::vector<int>> charater, std::vector<int> pos);
        std::string getName() const {return "ncurse";};
        std::vector<int> getPos(const std::string &id) {return _posMenu[id];};
    protected:
    private:
        int _key;
        WIN *_win;
        void drawObjMap(const std::string &type, int id, std::vector<int> pos);
        std::vector<std::string> _enemy;
        std::vector<std::string> _wall;
        std::vector<std::string> _objet;
        std::vector<std::string> _character;
        std::map<std::string, std::vector<std::string>> _Objmap;
        std::map<std::string, std::vector<int>> _posMenu;
};

#endif /* !NCURSE_HPP_ */
