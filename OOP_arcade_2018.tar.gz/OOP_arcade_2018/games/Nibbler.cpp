/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Nibbler.cpp
*/

#include "Nibbler.hpp"
#include <fstream>

extern "C" {
    Nibbler *allocatorGame() {
        return new Nibbler();
    }
    void deleterGame(Nibbler *ptr) {
        delete ptr;
    }
}

Nibbler::Nibbler()
{
    resetGame();
}

Nibbler::~Nibbler()
{

}

void Nibbler::updateGame(Arcade::Event event)
{
    if (_map[_nibbler.front().front()][_nibbler.front().back()] == 10) {
        _nibbler.push_back({0, 0});
        _map[_nibbler.front().front()][_nibbler.front().back()] = 0;
        int y = std::rand()%(_map.size() - 2) + 1;
        int x = std::rand()%(_map[0].size() - 2) + 1;
        _map[y][x] = 10;
        _score += 100;
    }
    for(unsigned int i = 1; i < _nibbler.size(); i++)
    {
        if (_nibbler.at(i)[0] == _nibbler.front().front() && _nibbler.at(i)[1] == _nibbler.front().back()) {
            _lose = true;
            return;
        }
    }
    if (_map[_nibbler.front().front()][_nibbler.front().back()] == 1) {
        _lose = true;
        return;
    }
    if (_dir != NOTHING)
    for(int i = _nibbler.size() - 2; i >= 0; i--)
        _nibbler.at(i + 1) = _nibbler.at(i);
    if ((event == Arcade::Event::KEYUP || _dir == UP) && _dir != DOWN) {
        _nibbler.front().front() -= 1;
        _dir = UP;
    }
    if ((event == Arcade::Event::KEYRIGHT || _dir == RIGHT) && _dir != LEFT) {
        _nibbler.front().back() += 1;
        _dir = RIGHT;
    }
    if ((event == Arcade::Event::KEYDOWN || _dir == DOWN) && _dir != UP) {
        _nibbler.front().front() += 1;
        _dir = DOWN;
    }
    if ((event == Arcade::Event::KEYLEFT || _dir == LEFT) && _dir != RIGHT) {
        _nibbler.front().back() -= 1;
        _dir = LEFT;
    }
    setPlayerPos(_nibbler);
}

void Nibbler::setMap(const std::string path)
{
    std::string m;
    std::ifstream level(path);

    if (level) {
        for (int i = 0; getline(level, m); i++) {
            std::vector<int> tmp;
            for (auto x: m) {
                tmp.push_back(x - 48);
            }
            _map.emplace(i, tmp);
        }
    } else
        throw std::exception();
}

void Nibbler::resetGame()
{
    std::vector<int> p = {20, 17};
    std::vector<int> p1 = {20, 16};
    std::vector<int> p2 = {20, 15};

    _map.clear();
    _nibbler.clear();
    _lose = false;
    _nibbler = std::vector<std::vector<int>>();
    _nibbler.push_back(p);
    _nibbler.push_back(p1);
    _nibbler.push_back(p2);
    _dir = NOTHING;
    setMap("rsc/nibblerLevel");
    int y = std::rand()%(_map.size() - 2) + 1;
    int x = std::rand()%(_map[0].size() - 2) + 1;
    _map[y][x] = 10;
    _score = 0;
}
