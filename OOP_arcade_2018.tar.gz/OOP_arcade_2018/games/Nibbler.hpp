/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Nibbler.hpp
*/

#ifndef NIBBLER_HPP
#define NIBBLER_HPP

#include "AGraph.hpp"
#include "AGame.hpp"

class Nibbler : public Arcade::AGame {
    public:
        Nibbler();
        ~Nibbler();
        void setPlayerPos(std::vector<std::vector<int>> character) {_nibbler = character;};
        void setBox(std::vector<int> pos) {(void)pos;};
        void setObject(std::vector<int> obj) {(void)obj;};
        std::vector<std::vector<int>> getCharacter() {return _nibbler;};
        void setMap(const std::string path);
        std::map<int, std::vector<int>> &getMap() {return (_map);};
        int getScore() const {return (_score);};
        void updateGame(Arcade::Event event);
        bool lose() const {return (_lose);};
        void resetGame();
        std::string getName() const {return "Nibbler";};
    private:
        enum Direction {
            NOTHING,
            UP,
            DOWN,
            RIGHT,
            LEFT,
        };
        bool _lose;
        std::vector<std::vector<int>> _nibbler;
        Direction _dir;
        std::map<int, std::vector<int>> _map;
        int _score;
        const std::vector<int> _pos;
};

#endif /* !NIBBLER_HPP */
