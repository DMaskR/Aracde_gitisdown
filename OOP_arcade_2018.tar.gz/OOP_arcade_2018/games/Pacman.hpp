/*
** EPITECH PROJECT, 2018
** OOP_arcade_2018
** File description:
** Pacman.hpp
*/

#ifndef PACMAN_HPP_
#define PACMAN_HPP_

#include "AGame.hpp"
#include "AGraph.hpp"

class Pacman : public Arcade::AGame {
    public:
        Pacman();
        ~Pacman();
        void setMap(const std::string path);
        void setBox(std::vector<int> pos) {(void)pos;};
        void setObject(std::vector<int> obj) {(void)obj;};
        int getScore() const {return (_score);};
        std::map<int, std::vector<int>> &getMap() {return (_map);};
        std::vector<std::vector<int>> getCharacter() = 0;
        std::string getName() const {return ("Pacman");};
        void resetGame();
        void updateGame(Arcade::Event event);
        bool lose() const {return (_lose);};
    protected:
        enum Direction {
            NOTHING,
            UP,
            DOWN,
            RIGHT,
            LEFT,
        };
        Direction _dir;
        std::vector<int> _character;
        std::vector<std::vector<int>> _enemys;
        bool _lose;
        std::map<int, std::vector<int>> _map;
        int _score;
};

#endif /* PACMAN_HPP_ */
